echo this tool is only for ethical usage only and not for commercial usage , use @ you own risk . Tool currently is only able to extract NTFS , ext3 , FAT32 images only.
echo "--------------------------------------------------------------------------------"
echo if you are getting a error now , executing the shell script ... then open the run.sh and give the image file name that you want to extract / work with ... and ensure you have replaced "--image_file_name.img" with "your_file_name.img"
echo "--------------------------------------------------------------------------------"
echo "Enter the username :"
read username
echo "--------------------------------------------------------------------------------"
echo your username is : "$username" 
echo press "Enter key" to continue :
sleep 3
echo "--------------------------------------------------------------------------------"
sudo python3 --version
echo ""
sudo python3 main.py --imagefilename.img

echo This analysis / extraction of image file was done by $username

