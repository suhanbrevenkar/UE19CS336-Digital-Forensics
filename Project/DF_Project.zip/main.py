from platform import *
import extract_windows
import extract_linux

from sys import *

os = system()

print("IMAGE FILE EXTRACTION STARTED...")

if(os=="Windows"):
    print("Your detected OS : Windows OS --- Starting extraction on windows...\n")
    extract_windows.extract(argv[1],argv[2])
else:
    print("Your detected OS : Linux OS --- Starting extraction on Linux...\n")
    extract_linux.extract(argv[1])
    
