import subprocess as sp
import os
from sys import argv

def extract(src):
    print("\ninitiating the extraction of "+src+" on Linux OS...\n")
    # Required functions
    def create_directory():
        print("\nCreating the directory(s) to mount "+src)
        os.system("mkdir /mnt")
        os.system("mkdir /mnt/sdb")
        os.system("mkdir /mnt/windows_mount")
        print("Done")



    # Get the present working directory
    cmd = "pwd"
    pwd = sp.getoutput(cmd)

    

    # Create mount directory
    if(os.path.exists("/mnt/sdb") == True):
        try:
            os.system("umount /mnt/sdb")
        finally:
            os.system("rm -r /mnt")
        create_directory()
    else:
        create_directory()



    # Start mounting
    os.system("mount -o loop "+src+" /mnt/sdb")



    # Get the contents
    cmd = "ls -r /mnt/sdb"
    ls = sp.getoutput(cmd)
    if(ls == "/mnt/sdb:"):
        print("A fatal error occurred while mounting the disk image. Exiting the program...")
        exit(1)
    else:
        print("\nContents in the root directory of "+src+" are:")
        print(ls)



    # Copy the contents
    if(os.path.exists("/"+pwd+"/sdb") == True):
        os.system("rm -r /"+pwd+"/sdb")
    os.system("cp -r /mnt/sdb "+pwd)
    print("\nSaved the contents to "+pwd+"/sdb")



    # Unmount
    os.system("umount /mnt/sdb")
    os.system("rm -r /mnt")
    print("\nUnmounted the image file and removed the directory.")
