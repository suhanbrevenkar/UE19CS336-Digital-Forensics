#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define B_MPBYTE1       0x42
#define B_MPBYTE2       0x4d
#define JPEGSTART1      0xFF
#define JPEGSTART2      0xD8
#define JPEGSTART3      0xFF
#define JPEGEND1        0xFF
#define JPEGEND2        0xD9

void reverse_bytes (unsigned int *i_size){
    unsigned int ul = *i_size;
    unsigned char *ptr = (unsigned char *) i_size;
    printf ("ul at entry is %x\n", ul);
    for (int i = 0; i < 4; i ++)
        *(ptr + 4 - (1 + i)) = ul >> (8 * i);
    ul = *((unsigned int *)ptr);
    printf ("ul at exit is %x\n", ul);
}
void copy_jpeg_file (FILE *fp, char *f_name){
    FILE *f_jpeg;
    unsigned char b_char1, b_char2, first_three [3];
    if ((f_jpeg = fopen (f_name, "wb+")) == NULL)
    {
        printf ("Unable to create file %s\n", f_name);
        exit (0);
    }
    fread (first_three, 3, 1, fp);
    fwrite (first_three, 3, 1, f_jpeg);
    while (1)
    {
        fread (&b_char1, 1, 1, fp);
        fwrite (&b_char1, 1, 1, f_jpeg);
        if (b_char1 == JPEGEND1)
        {
            fread (&b_char2, 1, 1, fp);
            if (b_char2 == JPEGEND2)
            {
                fwrite (&b_char2, 1, 1, f_jpeg);
                break;
            }
            else
                fwrite (&b_char2, 1, 1, f_jpeg);
        }
    }
    fclose (f_jpeg);
}
void copy_b_file (FILE *fp, char *f_name, long f_size){
    FILE *fbmp;
    unsigned char buf [1000];
    int i_full = f_size / 1000;
    int i_remain = f_size % 1000;
    //printf ("Inside copy fpos is %ld\n", ftell (fp));
    if ((fbmp = fopen (f_name, "wb+")) == NULL)
    {
        printf ("Unable to create file %s\n", f_name);
        exit (0);
    }
    for (int k = 0; k < i_full; k ++)
    {
        fread (buf, 1000, 1, fp);
        fwrite (buf, 1000, 1, fbmp);
    }
    fread (buf, i_remain, 1, fp);
    fwrite (buf, i_remain, 1, fbmp);
    fclose (fbmp);
}
int main (int argc, char **argv){
    char hostname[1024];
    hostname[1023] = '\0';
    gethostname(hostname, 1023);
    printf ("Extracted the files with log in name %s on host %s\n", getlogin(), hostname);
    FILE *fp;
    struct stat f_stat;
    unsigned char byte1, byte2, byte3;
    unsigned int f_size;
    long fpos;
    char f_name [30], f_name2 [30];
    char tmp;
    int k = 0, j = 0;
    int df_size;        // Size of input file
    if (argc < 2)
    {
        printf ("Usage: %s <filename>", argv[0]);
        exit (0);
    }
    stat (argv[1], &f_stat);
    if ((fp = fopen (argv[1], "rb")) == NULL)
    {
        printf ("Error opening the file %s", argv[1]);
        exit (0);
    }
    while (1)
    {
        fpos = ftell (fp);
        if (fpos >= f_stat.st_size)
                break;
        fread (&byte1, 1, 1, fp);
        //printf ("byte1 is %x\n", byte1);
        if (byte1 == B_MPBYTE1) // For identifying the bitmap file
        {
            fread (&byte2, 1, 1, fp);
            //printf ("byte2 is %x\n", byte2);
            //printf ("At position %ld\n", ftell (fp));
            if (byte2 == B_MPBYTE2)     // A Bitmap file is found
            {
                f_size = 0;
                fread (&f_size, 4, 1, fp);
                //printf ("File size is %u\n", f_size);
                // scanf ("%c", &tmp);
                memset (f_name, 0, 30);
                sprintf (f_name, "%s%d%s", getlogin(), k, ".bmp");
                k++;
                fseek (fp, fpos, SEEK_SET);
                copy_b_file (fp, f_name, f_size);
            }
            // printf ("The file position is %ld\n", ftell (fp));
        }
        else if (byte1 == JPEGSTART1)   // For identifying the JPEG file
        {
            fread (&byte2, 1, 1, fp);
            if (byte2 == JPEGSTART2)
            {
                fread (&byte3, 1, 1, fp);
                if (byte3 == JPEGSTART3)
                {
                    memset (f_name2, 0, 30);
                    sprintf (f_name2, "%s%d%s", getlogin(), j, ".jpeg");
                    j++;
                    fseek (fp, fpos, SEEK_SET);
                    copy_jpeg_file (fp, f_name2);
                }
            }
        else
            continue;
        }
    }
    fclose (fp);
}